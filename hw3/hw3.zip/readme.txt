This is a read me which informs you on how to run the smallsh.c program with the grading script

1. gcc smallsh.c -o smallsh
2. p3testscript > mytest 2>&1
3. vim mytest
